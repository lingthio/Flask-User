========
Features
========

* Register (sign up)
* Confirm email
* Login (Sign in) with email or username
* Logout (Sign out)
* Change username
* Change password
* Forgot password (Reset password)
* Password encryption through passlib and py-bcript
* Internationalization through Flask-Babel
* Session management through Flask-Login
* Email management through Flask-Mail

Configurable Settings
---------------------
::

    # Features
    USER_ENABLE_CHANGE_PASSWORD     = True
    USER_ENABLE_CHANGE_USERNAME     = True
    USER_ENABLE_FORGOT_PASSWORD     = True
    USER_ENABLE_REGISTRATION        = True
    USER_REQUIRE_EMAIL_CONFIRMATION = True
    USER_REQUIRE_INVITATION         = False

    # Settings
    USER_CONFIRM_EMAIL_EXPIRATION   = 2*24*3600  # 2 days
    USER_LOGIN_WITH_USERNAME        = False
    USER_REGISTER_WITH_EMAIL        = True
    USER_RESET_PASSWORD_EXPIRATION  = 2*24*3600  # 2 days
    USER_RETYPE_PASSWORD            = True

    # URLs
    USER_CHANGE_PASSWORD_URL            = '/user/change-password'
    USER_CHANGE_USERNAME_URL            = '/user/change-username'
    USER_CONFIRM_EMAIL_URL              = '/user/confirm-email/<token>'
    USER_FORGOT_PASSWORD_URL            = '/user/forgot-password'
    USER_LOGIN_URL                      = '/user/login'
    USER_LOGOUT_URL                     = '/user/logout'
    USER_REGISTER_URL                   = '/user/register'
    USER_RESEND_CONFIRMATION_EMAIL_URL  = '/user/resend-confirmation-email'
    USER_RESET_PASSWORD_URL             = '/user/reset-password/<token>'

    # Templates
    USER_CHANGE_USERNAME_TEMPLATE           = 'flask_user/change_username.html'
    USER_CHANGE_PASSWORD_TEMPLATE           = 'flask_user/change_password.html'
    USER_FORGOT_PASSWORD_TEMPLATE           = 'flask_user/forgot_password.html'
    USER_LOGIN_TEMPLATE                     = 'flask_user/login.html'
    USER_REGISTER_TEMPLATE                  = 'flask_user/register.html'
    USER_RESEND_CONFIRMATION_EMAIL_TEMPLATE = 'flask_user/resend_confirmation_email.html'
    USER_RESET_PASSWORD_TEMPLATE            = 'flask_user/reset_password.html'


Customizable Emails
-------------------
All default email subjects, HTML messages and Text messages can be customized by providing
a customized version in your application's ``templates/flask_user/emails`` subdirectory::

- templates/flask_user/emails/base_[message.html|message.txt|subject.txt]
- templates/flask_user/emails/confirmation_[message.html|message.txt|subject.txt]
- templates/flask_user/emails/reset_password_[message.html|message.txt|subject.txt]

| They make full use of Jinja2 templating.
| Base templates are used to place common elements in one place.


Customizable Functions
----------------------
::

    # Forms
    user_manager.change_password_form
    user_manager.change_username_form
    user_manager.forgot_password_form
    user_manager.login_form
    user_manager.register_form
    user_manager.reset_password_form

    # Validators
    user_manager.password_validator
        # Default: at least 6 chars, 1 upper case letter, 1 lower case letter, 1 digit
    user_manager.username_validator
        # Default: at least 3 alphanumeric characters

    # View functions
    user_manager.change_password_view_function
    user_manager.change_username_view_function
    user_manager.confirm_email_view_function
    user_manager.forgot_password_view_function
    user_manager.login_view_function
    user_manager.logout_view_function
    user_manager.register_view_function
    user_manager.resend_confirmation_email_view_function
    user_manager.reset_password_view_function

    # Password encryption methods
    user_manager.crypt_context
        # Default: CryptContext(schemes=['bcrypt', 'sha512_crypt', 'pbkdf2_sha512'], default='bcrypt')

